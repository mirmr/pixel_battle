export type Pixel = {
  rowInd: number;
  colInd: number;
  color: string;
};

export type Grid = Pixel[][];
